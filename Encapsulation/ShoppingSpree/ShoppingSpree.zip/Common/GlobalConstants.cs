﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ShoppingSpree.Common
{
    public static class GlobalConstants
    {
        public const string EmptyNameExpMsg = "Name cannot be empty";
        public const string NegMoneyExpMsg = "Money cannot be negative";
        
    }
}
