﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BirthdayCelebrations.Contracts
{
    public interface IBirthdayable
    {
        public DateTime BirthDate { get; }
    }
}
