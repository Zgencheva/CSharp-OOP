﻿using System;

using BorderControl.Core;

namespace BorderControl
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
