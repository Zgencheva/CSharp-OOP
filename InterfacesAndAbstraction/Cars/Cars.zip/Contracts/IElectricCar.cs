﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cars.Contracts
{
    public interface IElectricCar
    {
        public int Batery { get; }
    }
}
