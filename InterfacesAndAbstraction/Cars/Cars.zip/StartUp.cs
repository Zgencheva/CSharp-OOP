﻿using System;

using Cars.Core;

namespace Cars
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine engine = new Engine();
            engine.Run();

        }
    }
}
