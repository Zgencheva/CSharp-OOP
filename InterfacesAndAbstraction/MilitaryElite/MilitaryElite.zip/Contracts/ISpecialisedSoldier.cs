﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryElite.Contracts
{
    interface ISpecialisedSoldier
    {
        public string Corp { get; }
    }
}
