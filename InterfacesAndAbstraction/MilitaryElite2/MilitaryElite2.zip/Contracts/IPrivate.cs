﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryElite2.Contracts
{
    public interface IPrivate
    {
        public decimal Salary { get; }
    }
}
