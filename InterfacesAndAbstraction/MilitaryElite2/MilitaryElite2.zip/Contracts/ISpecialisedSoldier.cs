﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryElite2.Contracts
{
    interface ISpecialisedSoldier
    {
        public string Corp { get; }
    }
}
