﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MilitaryElite2.Contracts
{
    public interface ISpy
    {
        public int CodeNumber { get; }
    }
}
