﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles.Core.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}
