﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm.Common
{
    public class ExceptionMessages
    {
        public const string InvalidFoodType = "{0} does not eat {1}!";
    }
}
